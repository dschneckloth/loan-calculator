﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Schneckloth_FINAL
{
    class Loan
    {
        private double principal;   // >= 0
        private double rate;    // >= 0
        private int months; // >= 1

        //Properties

        public double Principal
        {
            get
            {
                return principal;
            }
            set
            {
                if (value > 0)
                {
                    principal = value;
                }
                else
                {
                    principal = 0;
                }
            }
        }

        public double Rate
        {
            get
            {
                return rate;
            }
            set
            {
                if (value > 0)
                {
                    rate = value;
                }
                else
                {
                    rate = 0;
                }
            }
        }


        public int Months
        {
            get
            {
                return months;
            }
            set
            {
                if (value > 1)
                {
                    months = value;
                }
                else
                {
                    months = 1;
                }
            }
        }

        // default constructor

        public Loan()
        {
            Principal = 2.5;
            Rate = 1.4;
            Months = 12;
        }

        // parameterized constructor

        public Loan(double newPrincipal, double newRate, int newMonths)
        {
            Principal = newPrincipal;
            Rate = newRate;
            Months = newMonths;
        }


        // Methods

        public double GetInterest()
        {
            double interest = principal * (rate / 100) * (months / 12);
            return interest;
        }

        public double GetAccruedAmount()
        {
            double accruedamount = principal + GetInterest();
            return accruedamount;
        }

      
    }
}
