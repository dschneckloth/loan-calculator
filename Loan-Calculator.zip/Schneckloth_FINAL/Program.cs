﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Schneckloth_FINAL
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.BackgroundColor = ConsoleColor.White;
            Console.ForegroundColor = ConsoleColor.DarkBlue;
            Console.Clear();

            Console.ForegroundColor = ConsoleColor.Black;
            Console.WriteLine("\t\t SCHNECKLOTH LOAN CALCULATOR \t\t\n");
            Console.ForegroundColor = ConsoleColor.DarkBlue;
            bool parseOkay;
            string name;
            double principal;
            int months;
            List<Loan> loan = new List<Loan>();
            double totalaccruedamount = 0.0;
            
            for(int i = 0; i <= 2; i++)
            {
                Console.Write("\n\nEnter the name of loan {0}: ", i+1);
                Console.ForegroundColor = ConsoleColor.DarkCyan;
                name = Console.ReadLine();
                Console.ForegroundColor = ConsoleColor.DarkBlue;

                Console.Write("Enter the principal of loan {0} (Example: 30000): ", i + 1);
                Console.ForegroundColor = ConsoleColor.DarkCyan;
                parseOkay = double.TryParse(Console.ReadLine(), out principal);
                Console.ForegroundColor = ConsoleColor.DarkBlue;
                while (parseOkay != true)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Invalid entry. Try again.");
                    Console.ForegroundColor = ConsoleColor.DarkBlue;
                    Console.Write("Enter the principal of loan {0}: ", i + 1);
                    Console.ForegroundColor = ConsoleColor.DarkCyan;
                    parseOkay = double.TryParse(Console.ReadLine(), out principal);
                    Console.ForegroundColor = ConsoleColor.DarkBlue;
                }


                Console.Write("Enter how many months to pay off loan {0}: ", i+1);
                Console.ForegroundColor = ConsoleColor.DarkCyan;
                parseOkay = int.TryParse(Console.ReadLine(), out months);
                Console.ForegroundColor = ConsoleColor.DarkBlue;
                while(parseOkay!=true)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Invalid entry. Try again.");
                    Console.ForegroundColor = ConsoleColor.DarkBlue;
                    Console.Write("Enter how many months to pay off loan {0}: ", i + 1);
                    Console.ForegroundColor = ConsoleColor.DarkCyan;
                    parseOkay = int.TryParse(Console.ReadLine(), out months);
                    Console.ForegroundColor = ConsoleColor.DarkBlue;
                }

                double rate = 3.5;
                // assuming int rate to pay off all loans is 3.5%

                Loan newLoan = new Loan(principal, rate, months);
                loan.Add(newLoan);
                Console.ForegroundColor = ConsoleColor.DarkGreen;
                Console.WriteLine("\nLoan {0}, {1}, has a monthly payment of {2:C}.", i+1, name,newLoan.GetAccruedAmount()/(double)months);
                Console.ForegroundColor = ConsoleColor.DarkBlue;

                totalaccruedamount += newLoan.GetAccruedAmount();
            }
            double maxInterest = 0;
           
            foreach(Loan loan1 in loan)
            {
                if(loan1.GetInterest() > maxInterest)
                {
                    maxInterest = loan1.GetInterest();
                }
            }

            Console.WriteLine("___________________________________________________________________________________________");

            Console.ForegroundColor = ConsoleColor.DarkGreen;
            Console.WriteLine("\n\nYour total accrued loan amount comes to {0:C}. ", totalaccruedamount);
            Console.WriteLine("Your highest interest owed is {0:C}.", maxInterest);
            Console.ForegroundColor = ConsoleColor.DarkBlue;



           


            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("\n\n\t\tPress any key to exit...");
            Console.ReadKey();
        }
    }
}
